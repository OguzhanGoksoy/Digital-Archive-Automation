﻿using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Views.Grid;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ArchiveManager {
    internal static class db {
        private static string _db_name = "archive_manager";
        private static string _user_name = "sa";
        private static string _psw = "1234";

        internal static SqlConnection cn = new SqlConnection("Server=.;Database=" + _db_name + ";User Id=" + _user_name + ";Password=" + _psw + ";");

        internal static bool open_connection() {
            try { cn.Open(); return true; }
            catch(Exception ex) { return false; }
        }

        internal static bool close_connection() {
            try { cn.Close(); return true; }
            catch(Exception ex) { return false; }
        }

        internal static bool run_query(string sql) {
            try {
                using(SqlCommand cmd = new SqlCommand(sql, db.cn)) {
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
            }
            catch(Exception ex) {
                return false;
            }
            return true;
        }

        internal static bool run_query(string sql, ref object response) {
            try {
                response = null;
                using(SqlCommand cmd = new SqlCommand(sql, cn)) {
                    response = cmd.ExecuteScalar();
                    cmd.Dispose();
                }
            }
            catch(Exception ex) { return false; }
            return true;
        }

        public static bool run_query(DataTable dt, string sql) {
            try {
                using(SqlDataAdapter adp = new SqlDataAdapter(sql, cn)) {
                    dt.Rows.Clear(); dt.Columns.Clear(); adp.Fill(dt); adp.Dispose();
                }
            }
            catch(Exception ex) { return false; }
            return true;
        }

        internal static bool run_query(ref DataTable dt, string sql) {
            try {
                using(SqlDataAdapter adp = new SqlDataAdapter(sql, cn)) {
                    dt.Reset();
                    adp.Fill(dt);
                    adp.Dispose();
                }
            }
            catch(Exception ex) {
                ex = ex;
                return false;
            }
            return true;
        }

        internal static bool grid_load(DataTable dt, DataGridView gw, string sql, params string[] caption) {
            if(!run_query(ref dt, sql)) return false;

            gw.DataSource = dt;

            try {
                for(int i = 0; i < caption.Length; i++) {
                    gw.Columns[i].HeaderText = caption[i]; gw.Columns[i].Visible = !caption[i].StartsWith("!");
                }
            }
            catch(Exception ex) { return false; }

            return true;
        }

        public static byte grid_load(DataTable dt, GridControl gc, string sql, params string[] caption) {
            GridView gw = (gc.MainView as GridView);

            if(!run_query(dt, sql)) return 1;

            gw.ClearGrouping(); gc.DataSource = dt; gc.RefreshDataSource(); gw.PopulateColumns();

            try {
                for(int i = 0; i < caption.Length; i++) {
                    gw.Columns[i].Caption = caption[i]; gw.Columns[i].Visible = !caption[i].StartsWith("!");
                }
            }
            catch(Exception ex) { return 2; }

            gw.BestFitColumns(); return 0;
        }

        public static byte grid_load(object dt, GridControl gc, params string[] caption) {
            GridView gw = (gc.MainView as GridView);

            gw.ClearGrouping(); gc.DataSource = dt; gc.RefreshDataSource(); gw.PopulateColumns();

            try {
                for(int i = 0; i < caption.Length; i++) {
                    gw.Columns[i].Caption = caption[i]; gw.Columns[i].Visible = !caption[i].StartsWith("!");
                }
            }
            catch(Exception ex) { return 1; }

            gw.BestFitColumns(); return 0;
        }
    }
}
