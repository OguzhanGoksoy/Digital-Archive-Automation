﻿using System.Windows.Forms;

namespace ArchiveManager {
    /// <summary>
    /// MessageBox Utility
    /// </summary>
    public static class msg {
        public static void inf(string msg, string caption) {
            MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static void warn(string msg) {
            MessageBox.Show(msg, "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void warn(string msg, string caption) {
            MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void err(string msg) {
            MessageBox.Show(msg, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static void err(string msg, string caption) {
            MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static void hand(string msg, string caption) {
            MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }

        public static void stop(string msg, string caption) {
            MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }

        public static DialogResult yn(string msg, string caption) {
            return MessageBox.Show(msg, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

        public static DialogResult ync(string msg, string caption) {
            return MessageBox.Show(msg, caption, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
        }
    }
}
