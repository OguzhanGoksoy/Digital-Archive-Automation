﻿namespace ArchiveManager {
    partial class UserDefineUC {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserDefineUC));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.cancelBtn = new DevExpress.XtraEditors.SimpleButton();
            this.delBtn = new DevExpress.XtraEditors.SimpleButton();
            this.editBtn = new DevExpress.XtraEditors.SimpleButton();
            this.saveBtn = new DevExpress.XtraEditors.SimpleButton();
            this.newBtn = new DevExpress.XtraEditors.SimpleButton();
            this.editPanel = new DevExpress.XtraEditors.PanelControl();
            this.pswBox2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.extractFileCheck = new DevExpress.XtraEditors.CheckEdit();
            this.moveFileCheck = new DevExpress.XtraEditors.CheckEdit();
            this.renameFileCheck = new DevExpress.XtraEditors.CheckEdit();
            this.delFileCheck = new DevExpress.XtraEditors.CheckEdit();
            this.addFileCheck = new DevExpress.XtraEditors.CheckEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.moveDirCheck = new DevExpress.XtraEditors.CheckEdit();
            this.renameDirCheck = new DevExpress.XtraEditors.CheckEdit();
            this.delDirCheck = new DevExpress.XtraEditors.CheckEdit();
            this.creDirCheck = new DevExpress.XtraEditors.CheckEdit();
            this.pswBox1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.userNameBox = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.nameBox = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gc1 = new DevExpress.XtraGrid.GridControl();
            this.gw1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.editPanel)).BeginInit();
            this.editPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pswBox2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.extractFileCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.moveFileCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.renameFileCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delFileCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addFileCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.moveDirCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.renameDirCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delDirCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.creDirCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pswBox1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userNameBox.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameBox.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gc1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gw1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.cancelBtn);
            this.panelControl1.Controls.Add(this.delBtn);
            this.panelControl1.Controls.Add(this.editBtn);
            this.panelControl1.Controls.Add(this.saveBtn);
            this.panelControl1.Controls.Add(this.newBtn);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl1.Location = new System.Drawing.Point(0, 516);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(877, 34);
            this.panelControl1.TabIndex = 1;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Enabled = false;
            this.cancelBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("cancelBtn.ImageOptions.SvgImage")));
            this.cancelBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.cancelBtn.Location = new System.Drawing.Point(353, 6);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(110, 22);
            this.cancelBtn.TabIndex = 3;
            this.cancelBtn.Text = "Vazgeç";
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // delBtn
            // 
            this.delBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("delBtn.ImageOptions.SvgImage")));
            this.delBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.delBtn.Location = new System.Drawing.Point(469, 6);
            this.delBtn.Name = "delBtn";
            this.delBtn.Size = new System.Drawing.Size(110, 22);
            this.delBtn.TabIndex = 4;
            this.delBtn.Text = "Sil";
            this.delBtn.Click += new System.EventHandler(this.delBtn_Click);
            // 
            // editBtn
            // 
            this.editBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("editBtn.ImageOptions.SvgImage")));
            this.editBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.editBtn.Location = new System.Drawing.Point(121, 6);
            this.editBtn.Name = "editBtn";
            this.editBtn.Size = new System.Drawing.Size(110, 22);
            this.editBtn.TabIndex = 1;
            this.editBtn.Text = "Düzenle";
            this.editBtn.Click += new System.EventHandler(this.editBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.Enabled = false;
            this.saveBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("saveBtn.ImageOptions.SvgImage")));
            this.saveBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.saveBtn.Location = new System.Drawing.Point(237, 6);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(110, 22);
            this.saveBtn.TabIndex = 2;
            this.saveBtn.Text = "Kaydet";
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // newBtn
            // 
            this.newBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("newBtn.ImageOptions.SvgImage")));
            this.newBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.newBtn.Location = new System.Drawing.Point(5, 6);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(110, 22);
            this.newBtn.TabIndex = 0;
            this.newBtn.Text = "Yeni";
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // editPanel
            // 
            this.editPanel.Controls.Add(this.pswBox2);
            this.editPanel.Controls.Add(this.labelControl4);
            this.editPanel.Controls.Add(this.groupControl2);
            this.editPanel.Controls.Add(this.groupControl1);
            this.editPanel.Controls.Add(this.pswBox1);
            this.editPanel.Controls.Add(this.labelControl3);
            this.editPanel.Controls.Add(this.userNameBox);
            this.editPanel.Controls.Add(this.labelControl2);
            this.editPanel.Controls.Add(this.nameBox);
            this.editPanel.Controls.Add(this.labelControl1);
            this.editPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.editPanel.Location = new System.Drawing.Point(0, 0);
            this.editPanel.Name = "editPanel";
            this.editPanel.Size = new System.Drawing.Size(877, 117);
            this.editPanel.TabIndex = 0;
            // 
            // pswBox2
            // 
            this.pswBox2.EditValue = "";
            this.pswBox2.Location = new System.Drawing.Point(71, 87);
            this.pswBox2.Name = "pswBox2";
            this.pswBox2.Properties.MaxLength = 50;
            this.pswBox2.Properties.PasswordChar = '●';
            this.pswBox2.Size = new System.Drawing.Size(203, 20);
            this.pswBox2.TabIndex = 3;
            // 
            // labelControl4
            // 
            this.labelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.labelControl4.Location = new System.Drawing.Point(7, 90);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(58, 13);
            this.labelControl4.TabIndex = 10;
            this.labelControl4.Text = "Şifre Tekrarı";
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.extractFileCheck);
            this.groupControl2.Controls.Add(this.moveFileCheck);
            this.groupControl2.Controls.Add(this.renameFileCheck);
            this.groupControl2.Controls.Add(this.delFileCheck);
            this.groupControl2.Controls.Add(this.addFileCheck);
            this.groupControl2.Location = new System.Drawing.Point(548, 9);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(316, 98);
            this.groupControl2.TabIndex = 5;
            this.groupControl2.Text = "Dosya Yetkileri";
            // 
            // extractFileCheck
            // 
            this.extractFileCheck.Location = new System.Drawing.Point(8, 65);
            this.extractFileCheck.Name = "extractFileCheck";
            this.extractFileCheck.Properties.Caption = "Çıkart";
            this.extractFileCheck.Size = new System.Drawing.Size(100, 20);
            this.extractFileCheck.TabIndex = 3;
            // 
            // moveFileCheck
            // 
            this.moveFileCheck.Location = new System.Drawing.Point(220, 33);
            this.moveFileCheck.Name = "moveFileCheck";
            this.moveFileCheck.Properties.Caption = "Taşı";
            this.moveFileCheck.Size = new System.Drawing.Size(100, 20);
            this.moveFileCheck.TabIndex = 2;
            // 
            // renameFileCheck
            // 
            this.renameFileCheck.Location = new System.Drawing.Point(114, 65);
            this.renameFileCheck.Name = "renameFileCheck";
            this.renameFileCheck.Properties.Caption = "Yeniden Adlandır";
            this.renameFileCheck.Size = new System.Drawing.Size(100, 20);
            this.renameFileCheck.TabIndex = 4;
            // 
            // delFileCheck
            // 
            this.delFileCheck.Location = new System.Drawing.Point(114, 33);
            this.delFileCheck.Name = "delFileCheck";
            this.delFileCheck.Properties.Caption = "Sil";
            this.delFileCheck.Size = new System.Drawing.Size(100, 20);
            this.delFileCheck.TabIndex = 1;
            // 
            // addFileCheck
            // 
            this.addFileCheck.Location = new System.Drawing.Point(8, 33);
            this.addFileCheck.Name = "addFileCheck";
            this.addFileCheck.Properties.Caption = "Ekle";
            this.addFileCheck.Size = new System.Drawing.Size(100, 20);
            this.addFileCheck.TabIndex = 0;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.moveDirCheck);
            this.groupControl1.Controls.Add(this.renameDirCheck);
            this.groupControl1.Controls.Add(this.delDirCheck);
            this.groupControl1.Controls.Add(this.creDirCheck);
            this.groupControl1.Location = new System.Drawing.Point(282, 9);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(260, 98);
            this.groupControl1.TabIndex = 4;
            this.groupControl1.Text = "Klasör Yetkileri";
            // 
            // moveDirCheck
            // 
            this.moveDirCheck.Location = new System.Drawing.Point(114, 65);
            this.moveDirCheck.Name = "moveDirCheck";
            this.moveDirCheck.Properties.Caption = "Taşı";
            this.moveDirCheck.Size = new System.Drawing.Size(100, 20);
            this.moveDirCheck.TabIndex = 3;
            // 
            // renameDirCheck
            // 
            this.renameDirCheck.Location = new System.Drawing.Point(114, 33);
            this.renameDirCheck.Name = "renameDirCheck";
            this.renameDirCheck.Properties.Caption = "Yeniden Adlandır";
            this.renameDirCheck.Size = new System.Drawing.Size(100, 20);
            this.renameDirCheck.TabIndex = 1;
            // 
            // delDirCheck
            // 
            this.delDirCheck.Location = new System.Drawing.Point(8, 65);
            this.delDirCheck.Name = "delDirCheck";
            this.delDirCheck.Properties.Caption = "Sil";
            this.delDirCheck.Size = new System.Drawing.Size(100, 20);
            this.delDirCheck.TabIndex = 2;
            // 
            // creDirCheck
            // 
            this.creDirCheck.Location = new System.Drawing.Point(8, 33);
            this.creDirCheck.Name = "creDirCheck";
            this.creDirCheck.Properties.Caption = "Oluştur";
            this.creDirCheck.Size = new System.Drawing.Size(100, 20);
            this.creDirCheck.TabIndex = 0;
            // 
            // pswBox1
            // 
            this.pswBox1.EditValue = "";
            this.pswBox1.Location = new System.Drawing.Point(71, 61);
            this.pswBox1.Name = "pswBox1";
            this.pswBox1.Properties.MaxLength = 50;
            this.pswBox1.Properties.PasswordChar = '●';
            this.pswBox1.Size = new System.Drawing.Size(203, 20);
            this.pswBox1.TabIndex = 2;
            // 
            // labelControl3
            // 
            this.labelControl3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.labelControl3.Location = new System.Drawing.Point(43, 64);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(22, 13);
            this.labelControl3.TabIndex = 6;
            this.labelControl3.Text = "Şifre";
            // 
            // userNameBox
            // 
            this.userNameBox.Location = new System.Drawing.Point(71, 35);
            this.userNameBox.Name = "userNameBox";
            this.userNameBox.Properties.MaxLength = 50;
            this.userNameBox.Size = new System.Drawing.Size(203, 20);
            this.userNameBox.TabIndex = 1;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(10, 38);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(55, 13);
            this.labelControl2.TabIndex = 4;
            this.labelControl2.Text = "Kullanıcı Adı";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(71, 9);
            this.nameBox.Name = "nameBox";
            this.nameBox.Properties.MaxLength = 50;
            this.nameBox.Size = new System.Drawing.Size(203, 20);
            this.nameBox.TabIndex = 0;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(15, 12);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(50, 13);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "Adı Soyadı";
            // 
            // gc1
            // 
            this.gc1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gc1.Location = new System.Drawing.Point(0, 117);
            this.gc1.MainView = this.gw1;
            this.gc1.Name = "gc1";
            this.gc1.Size = new System.Drawing.Size(877, 399);
            this.gc1.TabIndex = 2;
            this.gc1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gw1});
            // 
            // gw1
            // 
            this.gw1.GridControl = this.gc1;
            this.gw1.Name = "gw1";
            this.gw1.OptionsBehavior.Editable = false;
            this.gw1.OptionsFind.AlwaysVisible = true;
            this.gw1.OptionsView.ShowAutoFilterRow = true;
            this.gw1.OptionsView.ShowDetailButtons = false;
            this.gw1.OptionsView.ShowFooter = true;
            this.gw1.OptionsView.ShowGroupPanel = false;
            this.gw1.OptionsView.ShowViewCaption = true;
            this.gw1.ViewCaption = " ";
            this.gw1.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gw1_FocusedRowChanged);
            this.gw1.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gw1_CustomColumnDisplayText);
            // 
            // UserDefineUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gc1);
            this.Controls.Add(this.editPanel);
            this.Controls.Add(this.panelControl1);
            this.Name = "UserDefineUC";
            this.Size = new System.Drawing.Size(877, 550);
            this.Load += new System.EventHandler(this.UserDefineUC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.editPanel)).EndInit();
            this.editPanel.ResumeLayout(false);
            this.editPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pswBox2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.extractFileCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.moveFileCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.renameFileCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delFileCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addFileCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.moveDirCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.renameDirCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delDirCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.creDirCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pswBox1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userNameBox.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameBox.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gc1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gw1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.SimpleButton cancelBtn;
        private DevExpress.XtraEditors.SimpleButton delBtn;
        private DevExpress.XtraEditors.SimpleButton editBtn;
        private DevExpress.XtraEditors.SimpleButton saveBtn;
        private DevExpress.XtraEditors.SimpleButton newBtn;
        private DevExpress.XtraEditors.PanelControl editPanel;
        private DevExpress.XtraGrid.GridControl gc1;
        private DevExpress.XtraGrid.Views.Grid.GridView gw1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit userNameBox;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit nameBox;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit pswBox1;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.CheckEdit extractFileCheck;
        private DevExpress.XtraEditors.CheckEdit moveFileCheck;
        private DevExpress.XtraEditors.CheckEdit renameFileCheck;
        private DevExpress.XtraEditors.CheckEdit delFileCheck;
        private DevExpress.XtraEditors.CheckEdit addFileCheck;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.CheckEdit moveDirCheck;
        private DevExpress.XtraEditors.CheckEdit renameDirCheck;
        private DevExpress.XtraEditors.CheckEdit delDirCheck;
        private DevExpress.XtraEditors.CheckEdit creDirCheck;
        private DevExpress.XtraEditors.TextEdit pswBox2;
        private DevExpress.XtraEditors.LabelControl labelControl4;
    }
}
