﻿namespace ArchiveManager {
    partial class ArchiveForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ArchiveForm));
            this.dirPanel = new DevExpress.XtraEditors.PanelControl();
            this.dirTree = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn3 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn4 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn5 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn6 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.expandBtn = new DevExpress.XtraEditors.SimpleButton();
            this.moveDirBtn = new DevExpress.XtraEditors.SimpleButton();
            this.delDirBtn = new DevExpress.XtraEditors.SimpleButton();
            this.renameDirBtn = new DevExpress.XtraEditors.SimpleButton();
            this.creDirBtn = new DevExpress.XtraEditors.SimpleButton();
            this.filePanel = new DevExpress.XtraEditors.PanelControl();
            this.gc1 = new DevExpress.XtraGrid.GridControl();
            this.gw1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.renameFileBtn = new DevExpress.XtraEditors.SimpleButton();
            this.moveFileBtn = new DevExpress.XtraEditors.SimpleButton();
            this.extractFileBtn = new DevExpress.XtraEditors.SimpleButton();
            this.delFileBtn = new DevExpress.XtraEditors.SimpleButton();
            this.addFileBtn = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.dirPanel)).BeginInit();
            this.dirPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dirTree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filePanel)).BeginInit();
            this.filePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gc1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gw1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dirPanel
            // 
            this.dirPanel.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.dirPanel.Controls.Add(this.dirTree);
            this.dirPanel.Controls.Add(this.panelControl2);
            this.dirPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.dirPanel.Location = new System.Drawing.Point(0, 0);
            this.dirPanel.Name = "dirPanel";
            this.dirPanel.Size = new System.Drawing.Size(610, 561);
            this.dirPanel.TabIndex = 98;
            // 
            // dirTree
            // 
            this.dirTree.Appearance.FocusedRow.BackColor = System.Drawing.Color.LimeGreen;
            this.dirTree.Appearance.FocusedRow.Options.UseBackColor = true;
            this.dirTree.Caption = "Arşiv Klasörleri";
            this.dirTree.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1,
            this.treeListColumn2,
            this.treeListColumn3,
            this.treeListColumn4,
            this.treeListColumn5,
            this.treeListColumn6});
            this.dirTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dirTree.Location = new System.Drawing.Point(0, 0);
            this.dirTree.Name = "dirTree";
            this.dirTree.BeginUnboundLoad();
            this.dirTree.AppendNode(new object[] {
            null,
            null,
            "root",
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            null}, -1);
            this.dirTree.AppendNode(new object[] {
            null,
            null,
            "müzik",
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            null}, 0);
            this.dirTree.AppendNode(new object[] {
            null,
            null,
            "video",
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            null}, 0);
            this.dirTree.EndUnboundLoad();
            this.dirTree.OptionsBehavior.Editable = false;
            this.dirTree.OptionsBehavior.ResizeNodes = false;
            this.dirTree.OptionsCustomization.AllowBandMoving = false;
            this.dirTree.OptionsCustomization.AllowBandResizing = false;
            this.dirTree.OptionsCustomization.AllowColumnMoving = false;
            this.dirTree.OptionsCustomization.AllowColumnResizing = false;
            this.dirTree.OptionsCustomization.AllowQuickHideColumns = false;
            this.dirTree.OptionsFilter.AllowFilterEditor = false;
            this.dirTree.OptionsFind.AlwaysVisible = true;
            this.dirTree.OptionsMenu.EnableColumnMenu = false;
            this.dirTree.OptionsMenu.EnableFooterMenu = false;
            this.dirTree.OptionsMenu.ShowAutoFilterRowItem = false;
            this.dirTree.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.dirTree.OptionsSelection.KeepSelectedOnClick = false;
            this.dirTree.OptionsView.FocusRectStyle = DevExpress.XtraTreeList.DrawFocusRectStyle.RowFocus;
            this.dirTree.OptionsView.ShowCaption = true;
            this.dirTree.OptionsView.ShowIndicator = false;
            this.dirTree.OptionsView.ShowSummaryFooter = true;
            this.dirTree.Size = new System.Drawing.Size(610, 527);
            this.dirTree.TabIndex = 91;
            this.dirTree.TreeLevelWidth = 25;
            this.dirTree.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.dirTree_FocusedNodeChanged);
            // 
            // treeListColumn1
            // 
            this.treeListColumn1.Caption = "id";
            this.treeListColumn1.FieldName = "id";
            this.treeListColumn1.Name = "treeListColumn1";
            this.treeListColumn1.OptionsColumn.AllowEdit = false;
            this.treeListColumn1.OptionsColumn.AllowMove = false;
            this.treeListColumn1.OptionsColumn.AllowMoveToCustomizationForm = false;
            this.treeListColumn1.OptionsColumn.AllowSize = false;
            this.treeListColumn1.OptionsColumn.AllowSort = false;
            this.treeListColumn1.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.Integer;
            this.treeListColumn1.Width = 250;
            // 
            // treeListColumn2
            // 
            this.treeListColumn2.Caption = "dir_id";
            this.treeListColumn2.FieldName = "dir_id";
            this.treeListColumn2.Name = "treeListColumn2";
            this.treeListColumn2.OptionsColumn.AllowEdit = false;
            this.treeListColumn2.OptionsColumn.AllowMove = false;
            this.treeListColumn2.OptionsColumn.AllowMoveToCustomizationForm = false;
            this.treeListColumn2.OptionsColumn.AllowSize = false;
            this.treeListColumn2.OptionsColumn.AllowSort = false;
            this.treeListColumn2.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.Integer;
            // 
            // treeListColumn3
            // 
            this.treeListColumn3.Caption = "Klasör Adı";
            this.treeListColumn3.FieldName = "name";
            this.treeListColumn3.Name = "treeListColumn3";
            this.treeListColumn3.RowFooterSummary = DevExpress.XtraTreeList.SummaryItemType.Count;
            this.treeListColumn3.SummaryFooter = DevExpress.XtraTreeList.SummaryItemType.Count;
            this.treeListColumn3.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.String;
            this.treeListColumn3.Visible = true;
            this.treeListColumn3.VisibleIndex = 0;
            // 
            // treeListColumn4
            // 
            this.treeListColumn4.Caption = "Oluşturma Tarihi";
            this.treeListColumn4.FieldName = "cre_time";
            this.treeListColumn4.Format.FormatString = "dd.MM.yyyy HH:mm:ss";
            this.treeListColumn4.Format.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.treeListColumn4.Name = "treeListColumn4";
            this.treeListColumn4.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.DateTime;
            this.treeListColumn4.Visible = true;
            this.treeListColumn4.VisibleIndex = 1;
            // 
            // treeListColumn5
            // 
            this.treeListColumn5.Caption = "Değiştirme Tarihi";
            this.treeListColumn5.FieldName = "wri_time";
            this.treeListColumn5.Format.FormatString = "dd.MM.yyyy HH:mm:ss";
            this.treeListColumn5.Format.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.treeListColumn5.Name = "treeListColumn5";
            this.treeListColumn5.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.DateTime;
            this.treeListColumn5.Visible = true;
            this.treeListColumn5.VisibleIndex = 2;
            // 
            // treeListColumn6
            // 
            this.treeListColumn6.Caption = "Silindi";
            this.treeListColumn6.FieldName = "del";
            this.treeListColumn6.Name = "treeListColumn6";
            this.treeListColumn6.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.Boolean;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.expandBtn);
            this.panelControl2.Controls.Add(this.moveDirBtn);
            this.panelControl2.Controls.Add(this.delDirBtn);
            this.panelControl2.Controls.Add(this.renameDirBtn);
            this.panelControl2.Controls.Add(this.creDirBtn);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl2.Location = new System.Drawing.Point(0, 527);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(610, 34);
            this.panelControl2.TabIndex = 90;
            // 
            // expandBtn
            // 
            this.expandBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("expandBtn.ImageOptions.SvgImage")));
            this.expandBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.expandBtn.Location = new System.Drawing.Point(5, 6);
            this.expandBtn.Name = "expandBtn";
            this.expandBtn.Size = new System.Drawing.Size(110, 22);
            this.expandBtn.TabIndex = 4;
            this.expandBtn.Text = "Genişlet/Daralt";
            this.expandBtn.Click += new System.EventHandler(this.expandBtn_Click);
            // 
            // moveDirBtn
            // 
            this.moveDirBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("moveDirBtn.ImageOptions.SvgImage")));
            this.moveDirBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.moveDirBtn.Location = new System.Drawing.Point(469, 6);
            this.moveDirBtn.Name = "moveDirBtn";
            this.moveDirBtn.Size = new System.Drawing.Size(110, 22);
            this.moveDirBtn.TabIndex = 3;
            this.moveDirBtn.Text = "Klasör Taşı";
            this.moveDirBtn.Click += new System.EventHandler(this.moveDirBtn_Click);
            // 
            // delDirBtn
            // 
            this.delDirBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("delDirBtn.ImageOptions.SvgImage")));
            this.delDirBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.delDirBtn.Location = new System.Drawing.Point(237, 6);
            this.delDirBtn.Name = "delDirBtn";
            this.delDirBtn.Size = new System.Drawing.Size(110, 22);
            this.delDirBtn.TabIndex = 2;
            this.delDirBtn.Text = "Klasör Sil";
            this.delDirBtn.Click += new System.EventHandler(this.delDirBtn_Click);
            // 
            // renameDirBtn
            // 
            this.renameDirBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("renameDirBtn.ImageOptions.SvgImage")));
            this.renameDirBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.renameDirBtn.Location = new System.Drawing.Point(353, 6);
            this.renameDirBtn.Name = "renameDirBtn";
            this.renameDirBtn.Size = new System.Drawing.Size(110, 22);
            this.renameDirBtn.TabIndex = 1;
            this.renameDirBtn.Text = "Yeniden Adlandır";
            this.renameDirBtn.Click += new System.EventHandler(this.renameDirBtn_Click);
            // 
            // creDirBtn
            // 
            this.creDirBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("creDirBtn.ImageOptions.SvgImage")));
            this.creDirBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.creDirBtn.Location = new System.Drawing.Point(121, 6);
            this.creDirBtn.Name = "creDirBtn";
            this.creDirBtn.Size = new System.Drawing.Size(110, 22);
            this.creDirBtn.TabIndex = 0;
            this.creDirBtn.Text = "Klasör Ekle";
            this.creDirBtn.Click += new System.EventHandler(this.creDirBtn_Click);
            // 
            // filePanel
            // 
            this.filePanel.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.filePanel.Controls.Add(this.gc1);
            this.filePanel.Controls.Add(this.panelControl1);
            this.filePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.filePanel.Location = new System.Drawing.Point(610, 0);
            this.filePanel.Name = "filePanel";
            this.filePanel.Size = new System.Drawing.Size(610, 561);
            this.filePanel.TabIndex = 99;
            // 
            // gc1
            // 
            this.gc1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gc1.Location = new System.Drawing.Point(0, 0);
            this.gc1.MainView = this.gw1;
            this.gc1.Name = "gc1";
            this.gc1.Size = new System.Drawing.Size(610, 527);
            this.gc1.TabIndex = 92;
            this.gc1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gw1});
            // 
            // gw1
            // 
            this.gw1.GridControl = this.gc1;
            this.gw1.Name = "gw1";
            this.gw1.OptionsBehavior.Editable = false;
            this.gw1.OptionsFind.AlwaysVisible = true;
            this.gw1.OptionsView.ShowAutoFilterRow = true;
            this.gw1.OptionsView.ShowFooter = true;
            this.gw1.OptionsView.ShowGroupPanel = false;
            this.gw1.OptionsView.ShowViewCaption = true;
            this.gw1.ViewCaption = " ";
            this.gw1.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gw1_CustomColumnDisplayText);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.renameFileBtn);
            this.panelControl1.Controls.Add(this.moveFileBtn);
            this.panelControl1.Controls.Add(this.extractFileBtn);
            this.panelControl1.Controls.Add(this.delFileBtn);
            this.panelControl1.Controls.Add(this.addFileBtn);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl1.Location = new System.Drawing.Point(0, 527);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(610, 34);
            this.panelControl1.TabIndex = 0;
            // 
            // renameFileBtn
            // 
            this.renameFileBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("renameFileBtn.ImageOptions.SvgImage")));
            this.renameFileBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.renameFileBtn.Location = new System.Drawing.Point(353, 6);
            this.renameFileBtn.Name = "renameFileBtn";
            this.renameFileBtn.Size = new System.Drawing.Size(110, 22);
            this.renameFileBtn.TabIndex = 4;
            this.renameFileBtn.Text = "Yeniden Adlandır";
            this.renameFileBtn.Click += new System.EventHandler(this.renameFileBtn_Click);
            // 
            // moveFileBtn
            // 
            this.moveFileBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("moveFileBtn.ImageOptions.SvgImage")));
            this.moveFileBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.moveFileBtn.Location = new System.Drawing.Point(469, 6);
            this.moveFileBtn.Name = "moveFileBtn";
            this.moveFileBtn.Size = new System.Drawing.Size(110, 22);
            this.moveFileBtn.TabIndex = 3;
            this.moveFileBtn.Text = "Dosya Taşı";
            this.moveFileBtn.Click += new System.EventHandler(this.moveFileBtn_Click);
            // 
            // extractFileBtn
            // 
            this.extractFileBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("extractFileBtn.ImageOptions.SvgImage")));
            this.extractFileBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.extractFileBtn.Location = new System.Drawing.Point(121, 6);
            this.extractFileBtn.Name = "extractFileBtn";
            this.extractFileBtn.Size = new System.Drawing.Size(110, 22);
            this.extractFileBtn.TabIndex = 2;
            this.extractFileBtn.Text = "Dosya Çıkart";
            this.extractFileBtn.Click += new System.EventHandler(this.extractFileBtn_Click);
            // 
            // delFileBtn
            // 
            this.delFileBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("delFileBtn.ImageOptions.SvgImage")));
            this.delFileBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.delFileBtn.Location = new System.Drawing.Point(237, 6);
            this.delFileBtn.Name = "delFileBtn";
            this.delFileBtn.Size = new System.Drawing.Size(110, 22);
            this.delFileBtn.TabIndex = 1;
            this.delFileBtn.Text = "Dosya Sil";
            this.delFileBtn.Click += new System.EventHandler(this.delFileBtn_Click);
            // 
            // addFileBtn
            // 
            this.addFileBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("addFileBtn.ImageOptions.SvgImage")));
            this.addFileBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.addFileBtn.Location = new System.Drawing.Point(5, 6);
            this.addFileBtn.Name = "addFileBtn";
            this.addFileBtn.Size = new System.Drawing.Size(110, 22);
            this.addFileBtn.TabIndex = 0;
            this.addFileBtn.Text = "Dosya Ekle";
            this.addFileBtn.Click += new System.EventHandler(this.addFileBtn_Click);
            // 
            // ArchivePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1220, 561);
            this.Controls.Add(this.filePanel);
            this.Controls.Add(this.dirPanel);
            this.FormBorderEffect = DevExpress.XtraEditors.FormBorderEffect.None;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ArchivePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nesimi Samet SAĞLAM - Arşiv Yönetimi";
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.SizeChanged += new System.EventHandler(this.HomePage_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.dirPanel)).EndInit();
            this.dirPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dirTree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.filePanel)).EndInit();
            this.filePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gc1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gw1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private DevExpress.XtraEditors.PanelControl dirPanel;
        private DevExpress.XtraTreeList.TreeList dirTree;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn3;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn4;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn5;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn6;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton moveDirBtn;
        private DevExpress.XtraEditors.SimpleButton delDirBtn;
        private DevExpress.XtraEditors.SimpleButton renameDirBtn;
        private DevExpress.XtraEditors.SimpleButton creDirBtn;
        private DevExpress.XtraEditors.PanelControl filePanel;
        private DevExpress.XtraGrid.GridControl gc1;
        private DevExpress.XtraGrid.Views.Grid.GridView gw1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.SimpleButton moveFileBtn;
        private DevExpress.XtraEditors.SimpleButton extractFileBtn;
        private DevExpress.XtraEditors.SimpleButton delFileBtn;
        private DevExpress.XtraEditors.SimpleButton addFileBtn;
        private DevExpress.XtraEditors.SimpleButton renameFileBtn;
        private DevExpress.XtraEditors.SimpleButton expandBtn;
    }
}