﻿using System;
using System.Collections.Generic;

namespace ArchiveManager {
    /// <summary>
    /// Archive File System Type
    /// </summary>
    public static class archive_t {
        #region Utility Function Definions

        public static string date_to_str(DateTime dt) {
            if(dt == null) return "";

            return dt.ToString("dd.MM.yyyy HH:mm:ss");
        }

        public static string date_to_str(object dt) {
            if(dt == null) return "";

            return DateTime.Parse(dt.ToString()).ToString("dd.MM.yyyy HH:mm:ss");
        }

        public static string len_to_str(long bytes) {
            string str = "";
            double bytes_d = bytes;

            if(bytes_d < 1000) { str = "Bytes"; }
            else if(bytes_d >= 1000 && bytes_d < 1000000) { bytes_d /= 1000; str = "KBytes"; }
            else if(bytes_d >= 1000000 && bytes_d < 1000000000) { bytes_d /= 1000000; str = "MBytes"; }
            else if(bytes_d >= 1000000000) { bytes_d /= 1000000000; str = "GBytes"; }

            return bytes_d.ToString("G3") + " " + str;
        }

        #endregion

        #region Database Model Type Definions

        /// <summary>
        /// Klasör Tanım Kaydı Tip Tanımı
        /// </summary>
        public class dir_def_t {
            public int id { get; set; } = 0;
            public int dir_id { get; set; } = 0;
            public string name { get; set; } = "";
            public DateTime cre_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public DateTime wri_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int cre_user_id { get; set; } = 0;
            public bool del { get; set; } = false;
            public DateTime del_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int del_user_id { get; set; } = 0;

            public dir_def_t par_dir { get; set; } = null;
            public List<dir_def_t> dir_lst { get; set; } = null;
            public List<file_def_t> file_lst { get; set; } = null;

            public dir_def_t() { dir_lst = new List<dir_def_t>(); file_lst = new List<file_def_t>(); }
        }

        /// <summary>
        /// Dosya Tanım Kaydı Tip Tanımı
        /// </summary>
        public class file_def_t {
            public int id { get; set; } = 0;
            public int dir_id { get; set; } = 0;
            public string name { get; set; } = "";
            public string ext { get => name.Contains(".") ? name.Substring(name.LastIndexOf(".")) : "Dosya"; }
            public long size { get; set; } = 0;
            public DateTime cre_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public DateTime wri_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int cre_user_id { get; set; } = 0;
            public bool del { get; set; } = false;
            public DateTime del_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int del_user_id { get; set; } = 0;

            public file_def_t() { }
        }

        /// <summary>
        /// Part Tanım Kaydı Tip Tanımı
        /// </summary>
        public class part_def_t {
            public int id { get; set; } = 0;
            public string name { get; set; } = "";
            public long size { get; set; } = 0;
            public List<segment_t> segment_list { get; set; } = null;

            public long used_space() {
                long space = 0;
                segment_list.FindAll(i => i.file_id != 0).ForEach(j => space += j.lenght);
                return space;
            }

            public long free_space() {
                return size - used_space();
            }

            public part_def_t() { segment_list = new List<segment_t>(); }
        }

        /// <summary>
        /// Segment Kaydı Tip Tanımı
        /// </summary>
        public class segment_t {
            public int id { get; set; } = 0;
            public int part_id { get; set; } = 0;
            public int file_id { get; set; } = 0;
            public long address { get; set; } = 0;
            public long lenght { get; set; } = 0;

            public segment_t() { }
        }

        /// <summary>
        /// Kullanıcı Kaydı Tip Tanımı
        /// </summary>
        public class user_def_t {
            public int id { get; set; } = 0;
            public string name { get; set; } = "";
            public string user_name { get; set; } = "";
            public string psw { get; set; } = "";
            public DateTime cre_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int cre_user_id { get; set; } = 0;
            public bool del { get; set; } = false;
            public DateTime del_time { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int del_user_id { get; set; } = 0;
            public List<user_auth_def_t> auth_lst { get; set; } = null;

            public user_def_t() { auth_lst = new List<user_auth_def_t>(); }
        }

        /// <summary>
        /// Kullanıcı Yetki Kaydı Tip Tanımı
        /// </summary>
        public class user_auth_def_t {
            public int id { get; set; } = 0;
            public int user_id { get; set; } = 0;
            public string name { get; set; } = "";
            public bool del { get; set; } = false;

            public user_auth_def_t() { }
        }

        /// <summary>
        /// İşlem Log Kaydı Tip Tanımı
        /// </summary>
        public class proc_log_def_t {
            public int id { get; set; } = 0;
            public string proc_type { get; set; } = "";
            public int dir_id { get; set; } = 0;
            public int file_id { get; set; } = 0;
            public int source_dir_id { get; set; } = 0;
            public int dest_dir_id { get; set; } = 0;
            public string old_name { get; set; } = "";
            public DateTime proc_date { get; set; } = DateTime.Parse("01.01.2000 00:00:00");
            public int user_id { get; set; } = 0;

            public proc_log_def_t() { }
        }

        #endregion

        #region Archive Process Type

        /// <summary>
        /// Dosya Ekleme İşlemi Sonuç Tipi
        /// </summary>
        public class add_file_result_t {
            public file_def_t fdt { get; set; } = null;
            public byte result_code { get; set; } = 0;

            public add_file_result_t() { }
            public add_file_result_t(file_def_t fdt, byte result_code) { this.fdt = fdt; this.result_code = result_code; }
        }

        #endregion
    }
}
