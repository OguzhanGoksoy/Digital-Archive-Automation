﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

using static ArchiveManager.archive_t;
using static ArchiveManager.archive_db;

namespace ArchiveManager {
    /// <summary>
    /// Archive File System
    /// </summary>
    public static class archive_fs {
        #region Archive Variable Definions

        const int BUFF_SIZE = 1024;
        const long PART_SIZE = 200000000;
        const byte PART_NAME_LEN = 30;

        static string _work_dir = "";
        static byte[] _buff = new byte[BUFF_SIZE];
        static char[] chars = new char[] {
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
        };

        #endregion

        #region Archive File System Functions

        /// <summary>
        /// Arşivi Başlat
        /// </summary>
        /// <param name="archive_work_dir">Arşiv Dosyaları Ana Klasör Dizini</param>
        /// <returns></returns>
        public static bool fs_init(string archive_work_dir) {
            _work_dir = archive_work_dir;

            try {
                //Arşiv klasörünü kontrol et
                if(!Directory.Exists(_work_dir)) Directory.CreateDirectory(_work_dir);
            }
            catch(Exception ex) { return false; }

            return true;
        }

        /// <summary>
        /// Yeni Part Adı Oluştur
        /// </summary>
        /// <returns></returns>
        static string fs_new_part_name() {
            string part_name = "";
            Random rnd = new Random();

            for(byte i = 0; i < PART_NAME_LEN; i++) part_name += chars[rnd.Next(0, 25)];

            return part_name;
        }

        /// <summary>
        /// Arşive Dosya Ekle
        /// </summary>
        /// <param name="fi">FileInfo kaynak_dosya_info</param>
        /// <returns></returns>
        public static async Task<add_file_result_t> fs_add_file_async(dir_def_t ddt, string source_file_path) {
            return await Task<add_file_result_t>.Factory.StartNew(() => {
                long file_bytes_read = 0;
                FileInfo fi = new FileInfo(source_file_path);
                add_file_result_t afrt = new add_file_result_t();

                //Yeni dosya kaydı oluştur
                file_def_t fdt = new file_def_t() {
                    dir_id = ddt.id,
                    name = fi.Name,
                    size = fi.Length,
                    cre_time = DateTime.Now,
                    wri_time = DateTime.Now,
                    cre_user_id = login_info.act_user.id
                };
                if(!db_create_file_record(fdt)) { afrt.result_code = 1; return afrt; }

                //Part listesini al
                List<part_def_t> part_lst = db_list_part_records();

                //Kaynak dosyayı okuma işlemi için aç
                FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read);

                //Kaynak dosyanın tamamı okunmuş mu?
                while(file_bytes_read < fdt.size) {
                    //Boş alana sahip olan bir part bul
                    part_def_t prt = part_lst.Find(i => i.free_space() > 0);

                    //Boş alana sahip part yok ise => yeni part oluştur
                    if(prt == null) {
                        part_lst.Add(prt = new part_def_t() { name = fs_new_part_name(), size = PART_SIZE });
                        if(!db_create_part_record(prt)) { afrt.result_code = 2; return afrt; }
                    }

                    //Part dosyasını yazma işlemi için aç
                    FileStream fsp = new FileStream(Path.Combine(_work_dir, prt.name), FileMode.OpenOrCreate, FileAccess.Write);

                    //Part içindeki boş segmentleri bul
                    List<segment_t> segment_list = prt.segment_list.FindAll(j => j.file_id == 0);

                    for(ushort j = 0; j < segment_list.Count; j++) {
                        long segment_bytes_write = 0;
                        segment_t srt = segment_list[j];

                        //Part dosya yazma pozisyonunu boş bölüme ayarla
                        fsp.Seek(srt.address, SeekOrigin.Begin);

                        //Dosya verilerini boş part'a yaz
                        while(file_bytes_read < fdt.size && segment_bytes_write < srt.lenght) {
                            //Okuma miktarını hesapla
                            int bytes_to_read = (int)((segment_bytes_write + BUFF_SIZE) <= srt.lenght ? BUFF_SIZE : (srt.lenght - segment_bytes_write));

                            //Part'tan bi miktar veri oku
                            int bytes_read = fs.Read(_buff, 0, bytes_to_read);
                            file_bytes_read += bytes_read;

                            //Okunan veriyi dosyaya yaz
                            fsp.Write(_buff, 0, bytes_read);
                            segment_bytes_write += bytes_read;
                        }

                        //Boş segment bilgilerini güncelle
                        long segment_old_lenght = srt.lenght;
                        srt.file_id = fdt.id; srt.lenght = segment_bytes_write;

                        //Segment'e dosya id yaz
                        if(!db_set_segment_record(srt)) { afrt.result_code = 3; return afrt; }

                        //Aktif segment'in tamamı doldu mu?
                        if(segment_bytes_write < segment_old_lenght) {
                            //Part içine boş segment kaydı oluştur(aktif segmentin boş kalan kısmını ayır)
                            srt = new segment_t() {
                                part_id = prt.id,
                                file_id = 0,
                                address = (srt.address + segment_bytes_write),
                                lenght = (segment_old_lenght - segment_bytes_write)
                            };
                            prt.segment_list.Add(srt);
                            if(!db_create_segment_record(srt)) { afrt.result_code = 4; return afrt; }
                        }
                    }

                    //Part FileStream nesnesini kapat
                    fsp.Close();
                }

                //Dosya FileStream nesnesini kapat
                fs.Close();

                afrt.fdt = fdt; afrt.result_code = 0; return afrt;
            });
        }

        /// <summary>
        /// Arşivden Dosya Çıkart
        /// </summary>
        /// <param name="frt">file_def_t cikartilacak_dosya</param>
        /// <param name="file_path">string hedef_dizin</param>
        /// <returns></returns>
        public static async Task<byte> fs_extract_file_async(file_def_t frt, string file_path) {
            return await Task<byte>.Factory.StartNew(() => {
                long file_bytes_write = 0;

                //Part listesini al
                List<part_def_t> part_lst = db_list_part_records();

                if(part_lst == null) return 1;

                //Dosya verilerini içeren partları filtrele
                part_lst = part_lst.FindAll(i => i.segment_list.Find(j => j.file_id == frt.id) != null);

                //Hedef dosyayı yazma işlemi için aç
                FileStream fs = new FileStream(file_path, FileMode.Create, FileAccess.Write);

                for(ushort i = 0; i < part_lst.Count; i++) {
                    part_def_t prt = part_lst[i];

                    //Dosya verilerini içeren segmentleri filtrele
                    List<segment_t> segment_list = prt.segment_list.FindAll(j => j.file_id == frt.id);

                    //Part dosyasını okuma işlemi için aç
                    FileStream fsp = new FileStream(Path.Combine(_work_dir, prt.name), FileMode.Open, FileAccess.Read);

                    for(ushort j = 0; j < segment_list.Count; j++) {
                        long segment_bytes_read = 0;
                        segment_t srt = segment_list[j];

                        //Part segment okuma pozisyonunu ayarla
                        fsp.Seek(srt.address, SeekOrigin.Begin);

                        //Dosya verilerini boş part'a yaz
                        while(segment_bytes_read < srt.lenght) {
                            //Okuma miktarını hesapla
                            int bytes_to_read = (int)((segment_bytes_read + BUFF_SIZE) <= srt.lenght ? BUFF_SIZE : (srt.lenght - segment_bytes_read));

                            //Part'tan bi miktar veri oku
                            int bytes_read = fsp.Read(_buff, 0, bytes_to_read);
                            file_bytes_write += bytes_read;

                            //Okunan veriyi dosyaya yaz
                            fs.Write(_buff, 0, bytes_read);
                            segment_bytes_read += bytes_read;
                        }
                    }

                    //Part FileStream nesnesini kapat
                    fsp.Close();
                }

                //Dosya FileStream nesnesini kapat
                fs.Close();

                return 0;
            });
        }

        /// <summary>
        /// Arşivden Dosya Sil
        /// </summary>
        /// <param name="fdt">file_def_t silinecek_dosya</param>
        /// <returns></returns>
        public static async Task<byte> fs_delete_file_async(file_def_t fdt) {
            return await Task<byte>.Factory.StartNew(() => {
                //Segment listesini al
                List<segment_t> segment_lst = db_list_segment_records();

                if(segment_lst == null) return 1;

                //Seçilen dosya verilerini depolayan segmentleri filtrele
                segment_lst = segment_lst.FindAll(i => i.file_id == fdt.id);

                //Segmentleri sil(set file_id=0)
                for(ushort i = 0; i < segment_lst.Count; i++) {
                    segment_t srt = segment_lst[i]; srt.file_id = 0;
                    if(!db_set_segment_record(srt)) return 2;
                }

                fdt.del_time = DateTime.Now; fdt.del_user_id = login_info.act_user.id;

                //Dosyayı Sil
                if(!db_delete_file_record(fdt)) return 3;

                byte result_code = fs_defrag_free_segments_async();

                if(result_code > 0) return (byte)(result_code + 3);

                return 0;
            });
        }

        /// <summary>
        /// Arşiv Dosya Sistemini En İyi Duruma Getir
        /// </summary>
        /// <returns></returns>
        static byte fs_defrag_free_segments_async() {
            //Part listesini al
            List<part_def_t> part_lst = db_list_part_records();

            if(part_lst == null) return 1;

            //Boş segment içeren partları filtrele
            part_lst = part_lst.FindAll(i => i.segment_list.Find(j => j.file_id == 0) != null);

            for(int i = 0; i < part_lst.Count; i++) {
                part_def_t prt = part_lst[i];

                //Boş segmentleri filtrele
                List<segment_t> segment_list = prt.segment_list.FindAll(j => j.file_id == 0);

                for(int j = 0; j < segment_list.Count; j++) {
                    segment_t srt = segment_list[j];

                    if(srt.lenght == 0) continue;

                    for(int k = j + 1; k < segment_list.Count; k++) {
                        segment_t srtn = segment_list[k];

                        if(srtn.lenght == 0) continue;

                        if((srt.address + srt.lenght) == srtn.address) {
                            srt.lenght += srtn.lenght; srtn.lenght = 0;
                        }

                        if(!db_delete_segment_record(srtn)) return 2;
                    }

                    if(!db_set_segment_record(srt)) return 3;
                }
            }

            return 0;
        }

        #endregion
    }
}
