﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using static ArchiveManager.archive_t;

namespace ArchiveManager {
    /// <summary>
    /// Archive Database Functions
    /// </summary>
    public static class archive_db {
        #region Database Variable Definions

        static string _sql = "";

        #endregion

        #region Utility Function Definions

        public static string db_date_to_str(DateTime dt) {
            if(dt == null) return "";

            return dt.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public static string db_date_to_str(object dt) {
            if(dt == null) return "";

            return DateTime.Parse(dt.ToString()).ToString("yyyy-MM-dd HH:mm:ss");
        }

        #endregion

        #region Directory Record Database Functions

        public static bool db_create_dir_record(dir_def_t ddt) {
            object resp = null;

            _sql = string.Format("insert into dir_def(dir_id, name, cre_time, wri_time, cre_user_id, del) values({0}, '{1}', '{2}', '{3}', {4}, 0);" +
                "SELECT IDENT_CURRENT('dir_def')", ddt.dir_id, ddt.name, db_date_to_str(ddt.cre_time), db_date_to_str(ddt.wri_time), ddt.cre_user_id);

            if(!db.run_query(_sql, ref resp)) return false;

            ddt.id = int.Parse(resp.ToString());

            return true;
        }

        public static bool db_set_dir_record(dir_def_t ddt) {
            _sql = string.Format("update dir_def set dir_id={0}, name='{1}', wri_time='{2}' where id={3}",
                ddt.dir_id, ddt.name, db_date_to_str(ddt.wri_time), ddt.id);

            if(!db.run_query(_sql)) return false;

            return true;
        }

        public static bool db_delete_dir_record(dir_def_t ddt) {
            _sql = string.Format("update dir_def set del=1, del_time='{0}', del_user_id={1} where id={2}",
                db_date_to_str(ddt.del_time), ddt.del_user_id, ddt.id);
            return db.run_query(_sql);
        }

        public static List<dir_def_t> db_list_dir_records(dir_def_t par_ddt) {
            List<dir_def_t> dir_lst = null;
            DataTable dt = new DataTable();

            _sql = "select id, dir_id, name, cre_time, wri_time, del from dir_def where dir_id=" + (par_ddt != null ? par_ddt.id : 0);
            if(!db.run_query(ref dt, _sql)) { return null; }

            dir_lst = dt.AsEnumerable().Select(x => new dir_def_t {
                id = x.Field<int>("id"),
                dir_id = x.Field<int>("dir_id"),
                name = x.Field<string>("name"),
                cre_time = x.Field<DateTime>("cre_time"),
                wri_time = x.Field<DateTime>("wri_time"),
                del = x.Field<bool>("del"),
                par_dir = par_ddt
            }).ToList();

            foreach(dir_def_t ddt in dir_lst) {
                ddt.dir_lst = db_list_dir_records(ddt).FindAll(i => !i.del);
                ddt.file_lst = db_list_file_records(ddt.id).FindAll(i => !i.del);
            }

            return dir_lst;
        }

        #endregion

        #region File Record Database Functions

        public static bool db_create_file_record(file_def_t fdt) {
            object resp = null;

            _sql = string.Format("insert into file_def(dir_id, name, size, cre_time, wri_time, cre_user_id, del) values({0}, '{1}', {2}, '{3}', '{4}'," +
                " {5}, 0);SELECT IDENT_CURRENT('file_def')",
                 fdt.dir_id, fdt.name, fdt.size, db_date_to_str(fdt.cre_time), db_date_to_str(fdt.wri_time), fdt.cre_user_id);

            if(!db.run_query(_sql, ref resp)) return false;

            fdt.id = int.Parse(resp.ToString());

            return true;
        }

        public static bool db_set_file_record(file_def_t fdt) {
            _sql = string.Format("update file_def set dir_id={0}, name='{1}', wri_time='{2}' where id={3}",
                fdt.dir_id, fdt.name, db_date_to_str(fdt.wri_time), fdt.id);

            if(!db.run_query(_sql)) return false;

            return true;
        }

        public static bool db_delete_file_record(file_def_t fdt) {
            _sql = string.Format("update file_def set del=1, del_time='{0}', del_user_id={1} where id={2}",
                db_date_to_str(fdt.del_time), fdt.del_user_id, fdt.id);
            return db.run_query(_sql);
        }

        public static List<file_def_t> db_list_file_records(int dir_id) {
            List<file_def_t> file_lst = null;
            DataTable dt = new DataTable();

            _sql = "select id, dir_id, name, size, cre_time, wri_time, del from file_def" + (dir_id > -1 ? " where dir_id=" + dir_id : "");
            if(!db.run_query(ref dt, _sql)) { return null; }

            file_lst = dt.AsEnumerable().Select(x => new file_def_t {
                id = x.Field<int>("id"),
                dir_id = x.Field<int>("dir_id"),
                name = x.Field<string>("name"),
                size = x.Field<long>("size"),
                cre_time = x.Field<DateTime>("cre_time"),
                wri_time = x.Field<DateTime>("wri_time"),
                del = x.Field<bool>("del")
            }).ToList();

            return file_lst;
        }

        #endregion

        #region Part Record Database Functions

        public static bool db_create_part_record(part_def_t prt) {
            object resp = null;

            _sql = string.Format("insert into part_def(name, size) values('{0}', {1});SELECT IDENT_CURRENT('part_def')", prt.name, prt.size);

            if(!db.run_query(_sql, ref resp)) return false;

            prt.id = int.Parse(resp.ToString());

            //Part içine boş segment kaydı oluştur
            segment_t srt = new segment_t() {
                part_id = prt.id,
                file_id = 0,
                address = 0,
                lenght = prt.size
            };

            if(!db_create_segment_record(srt)) return false;

            prt.segment_list.Add(srt);

            return true;
        }

        public static bool db_delete_part_record(part_def_t prt) {
            _sql = string.Format("delete part_def where id={0};delete segment where part_id={0}", prt.id);
            return db.run_query(_sql);
        }

        public static List<part_def_t> db_list_part_records() {
            List<part_def_t> part_lst = null;
            DataTable dt = new DataTable();

            _sql = "select id, name, size from part_def";

            if(!db.run_query(ref dt, _sql)) { return null; }

            part_lst = dt.AsEnumerable().Select(x => new part_def_t {
                id = x.Field<int>("id"),
                name = x.Field<string>("name"),
                size = x.Field<long>("size"),
                segment_list = db_list_segment_records(x.Field<int>("id"))
            }).ToList();

            return part_lst;
        }

        #endregion

        #region Segment Record Database Functions

        public static bool db_create_segment_record(segment_t srt) {
            object resp = null;

            _sql = string.Format("insert into segment(part_id, file_id, address, lenght) values({0}, {1}, {2}, {3});SELECT IDENT_CURRENT('segment')",
                srt.part_id, srt.file_id, srt.address, srt.lenght);

            if(!db.run_query(_sql, ref resp)) return false;

            srt.id = int.Parse(resp.ToString());

            return true;
        }

        public static bool db_set_segment_record(segment_t srt) {
            _sql = string.Format("update segment set file_id={0}, address={1}, lenght={2} where id={3}", srt.file_id, srt.address, srt.lenght, srt.id);

            if(!db.run_query(_sql)) return false;

            return true;
        }

        public static bool db_delete_segment_record(segment_t srt) {
            _sql = string.Format("delete segment where id={0}", srt.id);
            return db.run_query(_sql);
        }

        public static List<segment_t> db_list_segment_records() {
            List<segment_t> segm_lst = null;
            DataTable dt = new DataTable();

            _sql = "select id, part_id, file_id, address, lenght from segment order by part_id, address";

            if(!db.run_query(ref dt, _sql)) { return null; }

            segm_lst = dt.AsEnumerable().Select(x => new segment_t {
                id = x.Field<int>("id"),
                part_id = x.Field<int>("part_id"),
                file_id = x.Field<int>("file_id"),
                address = x.Field<long>("address"),
                lenght = x.Field<long>("lenght")
            }).ToList();

            return segm_lst;
        }

        public static List<segment_t> db_list_segment_records(int part_id) {
            List<segment_t> segm_lst = null;
            DataTable dt = new DataTable();

            _sql = string.Format("select id, part_id, file_id, address, lenght from segment where part_id={0} order by address", part_id);

            if(!db.run_query(ref dt, _sql)) { return null; }

            segm_lst = dt.AsEnumerable().Select(x => new segment_t {
                id = x.Field<int>("id"),
                part_id = x.Field<int>("part_id"),
                file_id = x.Field<int>("file_id"),
                address = x.Field<long>("address"),
                lenght = x.Field<long>("lenght")
            }).ToList();

            return segm_lst;
        }

        #endregion

        #region User Record Database Functions

        public static bool db_create_user_record(user_def_t udt) {
            object resp = null;

            _sql = string.Format("insert into user_def(name, user_name, psw, cre_time, cre_user_id, del, del_time, del_user_id) values('{0}', '{1}'," +
                " '{2}', '{3}', {4}, 0, '{5}', {6});SELECT IDENT_CURRENT('user_def')", udt.name, udt.user_name, udt.psw, db_date_to_str(udt.cre_time),
                udt.cre_user_id, db_date_to_str(udt.del_time), udt.del_user_id);

            if(!db.run_query(_sql, ref resp)) return false;

            udt.id = int.Parse(resp.ToString());

            return true;
        }

        public static bool db_set_user_record(user_def_t udt) {
            _sql = string.Format("update user_def set name='{0}', user_name='{1}', psw='{2}' where id={3}", udt.name, udt.user_name, udt.psw, udt.id);

            if(!db.run_query(_sql)) return false;

            return true;
        }

        public static bool db_delete_user_record(user_def_t udt) {
            _sql = string.Format("update user_def set del=1, del_time='{0}', del_user_id={1} where id={2}",
                db_date_to_str(udt.del_time), udt.del_user_id, udt.id);
            return db.run_query(_sql);
        }

        public static List<user_def_t> db_list_user_records() {
            List<user_def_t> usr_lst = null;
            DataTable dt = new DataTable();

            _sql = "select id, name, user_name, psw, cre_time, cre_user_id, del, del_time, del_user_id from user_def";

            if(!db.run_query(ref dt, _sql)) { return null; }

            usr_lst = dt.AsEnumerable().Select(x => new user_def_t {
                id = x.Field<int>("id"),
                name = x.Field<string>("name"),
                user_name = x.Field<string>("user_name"),
                psw = x.Field<string>("psw"),
                cre_time = x.Field<DateTime>("cre_time"),
                cre_user_id = x.Field<int>("cre_user_id"),
                del = x.Field<bool>("del"),
                del_time = x.Field<DateTime>("del_time"),
                del_user_id = x.Field<int>("del_user_id")
            }).ToList();

            for(int i = 0; i < usr_lst.Count; i++) usr_lst[i].auth_lst = db_list_user_auth_records(usr_lst[i]);

            return usr_lst;
        }

        #endregion

        #region User Auth Record Database Functions

        public static bool db_create_user_auth_record(user_auth_def_t uadt) {
            object resp = null;

            _sql = string.Format("insert into user_auth_def(user_id, name, del) values({0}, '{1}', 0);SELECT IDENT_CURRENT('user_auth_def')",
                uadt.user_id, uadt.name);

            if(!db.run_query(_sql, ref resp)) return false;

            uadt.id = int.Parse(resp.ToString());

            return true;
        }

        public static bool db_set_user_auth_record(user_auth_def_t uadt) {
            _sql = string.Format("update user_auth_def set del={0} where id={1}", uadt.del ? 1 : 0, uadt.id);
            return db.run_query(_sql);
        }

        public static List<user_auth_def_t> db_list_user_auth_records(user_def_t udt) {
            List<user_auth_def_t> auth_lst = null;
            DataTable dt = new DataTable();

            _sql = "select id, user_id, name, del from user_auth_def where user_id=" + udt.id;

            if(!db.run_query(ref dt, _sql)) { return null; }

            auth_lst = dt.AsEnumerable().Select(x => new user_auth_def_t {
                id = x.Field<int>("id"),
                user_id = x.Field<int>("user_id"),
                name = x.Field<string>("name"),
                del = x.Field<bool>("del")
            }).ToList();

            return auth_lst;
        }

        #endregion

        #region Process Log Database Functions
        public static bool db_create_proc_log_record(proc_log_def_t pld) {
            _sql = string.Format("insert into proc_log(proc_type, dir_id, file_id, source_dir_id, dest_dir_id, old_name, proc_date, user_id)" +
                " values('{0}', {1}, {2}, {3}, {4}, '{5}', '{6}', {7})",
                pld.proc_type, pld.dir_id, pld.file_id, pld.source_dir_id, pld.dest_dir_id, pld.old_name, db_date_to_str(pld.proc_date), pld.user_id);

            if(!db.run_query(_sql)) return false;

            return true;
        }
        #endregion
    }
}
