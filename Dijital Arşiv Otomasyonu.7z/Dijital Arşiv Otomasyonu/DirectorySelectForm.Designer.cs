﻿namespace ArchiveManager {
    partial class DirectorySelectForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DirectorySelectForm));
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.expandBtn = new DevExpress.XtraEditors.SimpleButton();
            this.okBtn = new DevExpress.XtraEditors.SimpleButton();
            this.cancelBtn = new DevExpress.XtraEditors.SimpleButton();
            this.pathBox = new DevExpress.XtraEditors.TextEdit();
            this.dirTree = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn2 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn3 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn4 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn5 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn6 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pathBox.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dirTree)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.expandBtn);
            this.panelControl2.Controls.Add(this.okBtn);
            this.panelControl2.Controls.Add(this.cancelBtn);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl2.Location = new System.Drawing.Point(0, 509);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(785, 34);
            this.panelControl2.TabIndex = 2;
            // 
            // expandBtn
            // 
            this.expandBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("expandBtn.ImageOptions.SvgImage")));
            this.expandBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.expandBtn.Location = new System.Drawing.Point(5, 6);
            this.expandBtn.Name = "expandBtn";
            this.expandBtn.Size = new System.Drawing.Size(110, 22);
            this.expandBtn.TabIndex = 5;
            this.expandBtn.Text = "Genişlet/Daralt";
            this.expandBtn.Click += new System.EventHandler(this.expandBtn_Click);
            // 
            // okBtn
            // 
            this.okBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.okBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("okBtn.ImageOptions.SvgImage")));
            this.okBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.okBtn.Location = new System.Drawing.Point(554, 6);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(110, 22);
            this.okBtn.TabIndex = 0;
            this.okBtn.Text = "Onayla";
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cancelBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("cancelBtn.ImageOptions.SvgImage")));
            this.cancelBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.cancelBtn.Location = new System.Drawing.Point(670, 6);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(110, 22);
            this.cancelBtn.TabIndex = 1;
            this.cancelBtn.Text = "İptal";
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // pathBox
            // 
            this.pathBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.pathBox.Location = new System.Drawing.Point(0, 0);
            this.pathBox.Name = "pathBox";
            this.pathBox.Properties.ReadOnly = true;
            this.pathBox.Size = new System.Drawing.Size(785, 20);
            this.pathBox.TabIndex = 94;
            // 
            // dirTree
            // 
            this.dirTree.Appearance.FocusedRow.BackColor = System.Drawing.Color.LimeGreen;
            this.dirTree.Appearance.FocusedRow.Options.UseBackColor = true;
            this.dirTree.Caption = "Arşiv Klasörleri";
            this.dirTree.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1,
            this.treeListColumn2,
            this.treeListColumn3,
            this.treeListColumn4,
            this.treeListColumn5,
            this.treeListColumn6});
            this.dirTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dirTree.Location = new System.Drawing.Point(0, 20);
            this.dirTree.Name = "dirTree";
            this.dirTree.BeginUnboundLoad();
            this.dirTree.AppendNode(new object[] {
            null,
            null,
            "root",
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            null}, -1);
            this.dirTree.AppendNode(new object[] {
            null,
            null,
            "müzik",
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            null}, 0);
            this.dirTree.AppendNode(new object[] {
            null,
            null,
            "video",
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            new System.DateTime(2019, 12, 15, 0, 0, 0),
            null}, 0);
            this.dirTree.EndUnboundLoad();
            this.dirTree.OptionsBehavior.Editable = false;
            this.dirTree.OptionsBehavior.ResizeNodes = false;
            this.dirTree.OptionsCustomization.AllowBandMoving = false;
            this.dirTree.OptionsCustomization.AllowBandResizing = false;
            this.dirTree.OptionsCustomization.AllowColumnMoving = false;
            this.dirTree.OptionsCustomization.AllowColumnResizing = false;
            this.dirTree.OptionsCustomization.AllowQuickHideColumns = false;
            this.dirTree.OptionsFilter.AllowFilterEditor = false;
            this.dirTree.OptionsFind.AlwaysVisible = true;
            this.dirTree.OptionsMenu.EnableColumnMenu = false;
            this.dirTree.OptionsMenu.EnableFooterMenu = false;
            this.dirTree.OptionsMenu.ShowAutoFilterRowItem = false;
            this.dirTree.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.dirTree.OptionsSelection.KeepSelectedOnClick = false;
            this.dirTree.OptionsView.FocusRectStyle = DevExpress.XtraTreeList.DrawFocusRectStyle.RowFocus;
            this.dirTree.OptionsView.ShowCaption = true;
            this.dirTree.OptionsView.ShowIndicator = false;
            this.dirTree.OptionsView.ShowSummaryFooter = true;
            this.dirTree.Size = new System.Drawing.Size(785, 489);
            this.dirTree.TabIndex = 95;
            this.dirTree.TreeLevelWidth = 25;
            this.dirTree.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.dirTree_FocusedNodeChanged);
            // 
            // treeListColumn1
            // 
            this.treeListColumn1.Caption = "id";
            this.treeListColumn1.FieldName = "id";
            this.treeListColumn1.Name = "treeListColumn1";
            this.treeListColumn1.OptionsColumn.AllowEdit = false;
            this.treeListColumn1.OptionsColumn.AllowMove = false;
            this.treeListColumn1.OptionsColumn.AllowMoveToCustomizationForm = false;
            this.treeListColumn1.OptionsColumn.AllowSize = false;
            this.treeListColumn1.OptionsColumn.AllowSort = false;
            this.treeListColumn1.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.Integer;
            this.treeListColumn1.Width = 250;
            // 
            // treeListColumn2
            // 
            this.treeListColumn2.Caption = "dir_id";
            this.treeListColumn2.FieldName = "dir_id";
            this.treeListColumn2.Name = "treeListColumn2";
            this.treeListColumn2.OptionsColumn.AllowEdit = false;
            this.treeListColumn2.OptionsColumn.AllowMove = false;
            this.treeListColumn2.OptionsColumn.AllowMoveToCustomizationForm = false;
            this.treeListColumn2.OptionsColumn.AllowSize = false;
            this.treeListColumn2.OptionsColumn.AllowSort = false;
            this.treeListColumn2.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.Integer;
            // 
            // treeListColumn3
            // 
            this.treeListColumn3.Caption = "Klasör Adı";
            this.treeListColumn3.FieldName = "name";
            this.treeListColumn3.Name = "treeListColumn3";
            this.treeListColumn3.RowFooterSummary = DevExpress.XtraTreeList.SummaryItemType.Count;
            this.treeListColumn3.SummaryFooter = DevExpress.XtraTreeList.SummaryItemType.Count;
            this.treeListColumn3.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.String;
            this.treeListColumn3.Visible = true;
            this.treeListColumn3.VisibleIndex = 0;
            // 
            // treeListColumn4
            // 
            this.treeListColumn4.Caption = "Oluşturma Tarihi";
            this.treeListColumn4.FieldName = "cre_time";
            this.treeListColumn4.Format.FormatString = "dd.MM.yyyy HH:mm:ss";
            this.treeListColumn4.Format.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.treeListColumn4.Name = "treeListColumn4";
            this.treeListColumn4.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.DateTime;
            this.treeListColumn4.Visible = true;
            this.treeListColumn4.VisibleIndex = 1;
            // 
            // treeListColumn5
            // 
            this.treeListColumn5.Caption = "Değiştirme Tarihi";
            this.treeListColumn5.FieldName = "wri_time";
            this.treeListColumn5.Format.FormatString = "dd.MM.yyyy HH:mm:ss";
            this.treeListColumn5.Format.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.treeListColumn5.Name = "treeListColumn5";
            this.treeListColumn5.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.DateTime;
            this.treeListColumn5.Visible = true;
            this.treeListColumn5.VisibleIndex = 2;
            // 
            // treeListColumn6
            // 
            this.treeListColumn6.Caption = "Silindi";
            this.treeListColumn6.FieldName = "del";
            this.treeListColumn6.Name = "treeListColumn6";
            this.treeListColumn6.UnboundType = DevExpress.XtraTreeList.Data.UnboundColumnType.Boolean;
            // 
            // DirectorySelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 543);
            this.Controls.Add(this.dirTree);
            this.Controls.Add(this.pathBox);
            this.Controls.Add(this.panelControl2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DirectorySelectForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hedef Klasör Seçimi";
            this.Load += new System.EventHandler(this.DirectorySelectForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pathBox.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dirTree)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton okBtn;
        private DevExpress.XtraEditors.SimpleButton cancelBtn;
        private DevExpress.XtraEditors.SimpleButton expandBtn;
        private DevExpress.XtraEditors.TextEdit pathBox;
        private DevExpress.XtraTreeList.TreeList dirTree;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn2;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn3;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn4;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn5;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn6;
    }
}