﻿using System;
using System.Collections.Generic;

using static ArchiveManager.archive_t;

namespace ArchiveManager {
    public static class login_info {

        public enum auth_t : byte {
            cre_dir = 0,
            del_dir = 1,
            rename_dir = 2,
            move_dir = 3,
            add_file = 4,
            extract_file = 5,
            del_file = 6,
            rename_file = 7,
            move_file = 8
        }

        public static user_def_t act_user = null;
        public static List<user_def_t> usr_lst = null;

        public static bool has_auth(auth_t auth) {
            return act_user.auth_lst.Find(i => i.name == Enum.GetName(typeof(auth_t), auth) && !i.del) != null;
        }
    }
}
