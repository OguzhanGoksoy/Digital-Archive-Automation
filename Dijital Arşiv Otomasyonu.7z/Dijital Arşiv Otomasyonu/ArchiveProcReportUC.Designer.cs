﻿namespace ArchiveManager {
    partial class ArchiveProcReportUC {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ArchiveProcReportUC));
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.printBtn = new DevExpress.XtraEditors.SimpleButton();
            this.exportBtn = new DevExpress.XtraEditors.SimpleButton();
            this.gc1 = new DevExpress.XtraGrid.GridControl();
            this.gw1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gc1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gw1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.printBtn);
            this.panelControl2.Controls.Add(this.exportBtn);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl2.Location = new System.Drawing.Point(0, 526);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(960, 34);
            this.panelControl2.TabIndex = 91;
            // 
            // printBtn
            // 
            this.printBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("expandBtn.ImageOptions.SvgImage")));
            this.printBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.printBtn.Location = new System.Drawing.Point(5, 6);
            this.printBtn.Name = "printBtn";
            this.printBtn.Size = new System.Drawing.Size(110, 22);
            this.printBtn.TabIndex = 4;
            this.printBtn.Text = "Yazdır";
            this.printBtn.Click += new System.EventHandler(this.printBtn_Click);
            // 
            // exportBtn
            // 
            this.exportBtn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("creDirBtn.ImageOptions.SvgImage")));
            this.exportBtn.ImageOptions.SvgImageSize = new System.Drawing.Size(16, 16);
            this.exportBtn.Location = new System.Drawing.Point(121, 6);
            this.exportBtn.Name = "exportBtn";
            this.exportBtn.Size = new System.Drawing.Size(110, 22);
            this.exportBtn.TabIndex = 0;
            this.exportBtn.Text = "Excel\'e Aktar";
            this.exportBtn.Click += new System.EventHandler(this.exportBtn_Click);
            // 
            // gc1
            // 
            this.gc1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gc1.Location = new System.Drawing.Point(0, 0);
            this.gc1.MainView = this.gw1;
            this.gc1.Name = "gc1";
            this.gc1.Size = new System.Drawing.Size(960, 526);
            this.gc1.TabIndex = 93;
            this.gc1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gw1});
            // 
            // gw1
            // 
            this.gw1.GridControl = this.gc1;
            this.gw1.Name = "gw1";
            this.gw1.OptionsBehavior.Editable = false;
            this.gw1.OptionsFind.AlwaysVisible = true;
            this.gw1.OptionsView.ShowAutoFilterRow = true;
            this.gw1.OptionsView.ShowFooter = true;
            this.gw1.OptionsView.ShowGroupPanel = false;
            this.gw1.OptionsView.ShowViewCaption = true;
            this.gw1.ViewCaption = " ";
            // 
            // ArchiveProcReportUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gc1);
            this.Controls.Add(this.panelControl2);
            this.Name = "ArchiveProcReportUC";
            this.Size = new System.Drawing.Size(960, 560);
            this.Load += new System.EventHandler(this.ArchiveProcReportUC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gc1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gw1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton printBtn;
        private DevExpress.XtraEditors.SimpleButton exportBtn;
        private DevExpress.XtraGrid.GridControl gc1;
        private DevExpress.XtraGrid.Views.Grid.GridView gw1;
    }
}
